docker compose up -d --build
docker compose run --rm composer create-project sepand/laravel-mini-cms .
cp .env.example ./src/.env
docker compose up -d nginx
docker compose run --rm artisan key:generate
docker compose run --rm artisan migrate
docker compose run --rm artisan db:seed